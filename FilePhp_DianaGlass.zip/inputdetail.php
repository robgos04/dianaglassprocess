<?php
session_start();
//include("php/config.php");
//$connect=mysqli_connect("localhost","root","");
//mysqli_select_db($connect,"gudangceling");
//$connect = mysqli_connect("localhost","id3442564_robgos04","gudangceling","id3442564_gudangceling");
$connect = mysqli_connect("localhost","u6432664_renedew","tetsu13243546","u6432664_dianaglass");

$idproduk = $_POST['idbarang'];
$stok = $_POST['stok'];
$gudang = $_POST['gudang'];
$idsupplier = $_POST['idsupplier'];
$userstok = $_POST['userstok'];

$date = new DateTime("now", new DateTimeZone('Asia/Makassar') );
$tanggal = $date->format('Y-m-d H:i:s');

if (mysqli_connect_errno())
{
	echo "Failed to connect to MySQL" .
	mysqli_connect_error();
}

if($status=='On') {
    echo "<script type=\"text/javascript\">window.alert('Sudah ada Data Stok! Tidak perlu input data!');window.location.href = 'adminstok.php';</script>"; 
}else  {
	$query="INSERT INTO detailbarang (`idproduk`, `stok`, `idwarehouse`, `idsupplier`, `userstok`, `tanggalupdate`) VALUES ('$idproduk', '$stok', '$gudang', '$idsupplier', '$userstok', '$tanggal')";
	$result = mysqli_query($connect,$query);
	echo "<script type=\"text/javascript\">window.alert('Input Data Stok Berhasil.');window.location.href = 'adminstok.php';</script>"; 
}
?>