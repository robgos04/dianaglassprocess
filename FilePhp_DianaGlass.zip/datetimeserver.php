<?php
echo "The time is " . date("h:i:sa");
?>