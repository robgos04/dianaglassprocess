<?php 
/*
* iTech Empires:  Export Data from MySQL to CSV Script
* Version: 1.0.0
* Page: Export
*/
 
// Database Connection
require("php/config.php");
 
// get Users
$query = "select transaksi.idtransaksi, produk.kodeproduk, produk.namaproduk, warehouse.namawarehouse, transaksi.qty,  transaksi.keterangan, transaksi.sisastok, transaksi.customer, transaksi.usertransaksi, transaksi.tanggaltransaksi from transaksi,detailbarang,produk,warehouse where transaksi.iddetailbarang=detailbarang.iddetailbarang AND detailbarang.idproduk=produk.idproduk AND detailbarang.idwarehouse=warehouse.idwarehouse";
if (!$result = mysqli_query($con, $query)) {
    exit(mysqli_error($con));
}
 
$users = array();
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $users[] = $row;
    }
}
 
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=DataTransaksi_DianaGlass.csv');
$output = fopen('php://output', 'w');
fputcsv($output, array('ID Transaksi', 'Kode Barang', 'Nama Barang', 'Warehouse', 'Qty (pcs)', 'Status (2=Out/1=In)', 'Sisa stok sekarang (pcs)', 'Keterangan', 'User Update', 'Tanggal Transaksi'));
 
if (count($users) > 0) {
    foreach ($users as $row) {
        fputcsv($output, $row);
    }
}
?>